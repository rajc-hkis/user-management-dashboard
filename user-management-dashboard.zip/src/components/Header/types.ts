export interface NavLinkProps {
  children: React.ReactNode;
}
