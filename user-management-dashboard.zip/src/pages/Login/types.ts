export interface LSData {
  id: number;
  username: string;
  email: string;
  password: string;
  role: string;
}
